/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_1;
import java.util.Scanner;

/**
 *
 * @author piyawan
 */
public class ZellerTester {
    public static void main(String[] args){
        System.out.print("Enter year (e.g.,2012):");
        Scanner year = new Scanner(System.in);
        int y = year.nextInt();
        System.out.print("Enter month (1-12):");
        Scanner month = new Scanner(System.in);
        int m = month.nextInt();
        System.out.print("Enter day of the month (1-31):");
        Scanner dayOfmonth = new Scanner(System.in);
        int dm = dayOfmonth.nextInt();
        Zeller dayOfweek = new Zeller(dm,m,y);
        System.out.println("Day of the week is "+(dayOfweek.getDayOfweek()).day);
     
    }
}
