/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;
import java.util.Random;

/**
 *
 * @author piyawan
 */
public class CityGrid { 
     private int xCoor ; //x-coordinate
    private int yCoor ; //y-coordinate
    private int gridSize ; // size of city
    
    Random rand = new Random() ;
    
    public CityGrid()
    {
        gridSize = 100 ;
        xCoor = 5 ;
        yCoor = 5 ;
    }
    
    public void walk()
    {
        int walk = rand.nextInt(4);
        switch(walk)
        {
            case 0 :
                xCoor++;
                break;
            case 1 :
                xCoor--;
                break;
            case 2 :
                yCoor++;
                break;
            case 3 :
                yCoor--;
                break;
        }
        
    }
    
    public boolean isInCity()
    {
        boolean check = true;
        if(xCoor < 0 || xCoor > 10)
        {
            check = false ;
        }
        if(yCoor < 0 || yCoor >10)
        {
            check = false ;
        }
        return check ;
    }
    
    public void reset()
    {
        xCoor = 5 ;
        yCoor = 5 ;
    }
    
    public static void main(String[] args)
    {
        int step = 0;
        int maxStep = 0 ;
        int allStep = 0 ;
        double avgStep = 0 ;
        CityGrid city = new CityGrid() ;
        for(int i=0; i<10000 ;i++)
        {
            int cnt = 0 ;
            while(cnt < 1000)
            {
                city.walk();
                if(!city.isInCity())
                {
                    city.reset();
                    break ;
                }else{
                    step += 1 ;
                    cnt += 1 ;
                }
            }
            if(step > maxStep)
                {
                    maxStep = step ;
                }
            allStep += step ;
            step = 0 ;
        }
        avgStep = allStep/10000.0 ;
        System.out.println("Average number of steps that a person can take and is still in the city: "+avgStep);
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+maxStep);
    }
    
}


    