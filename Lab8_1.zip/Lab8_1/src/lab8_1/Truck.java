/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author piyawan
 */
public class Truck extends Car{
    private double weight;
    private double M_weight;
    public Truck(double gas,double efficiency,double weight,double M_weight){
        super(gas,efficiency);
        if(weight>M_weight){
            weight=M_weight;}
        else{
            this.weight=weight;
        }
    }
    @Override
    public void drive(double distance){
        double use;
        Usegas = distance/efficiency;
        if(weight<1){
            use = Usegas;
        }
        else if(weight<=10){
            use = (Usegas*110)/100;
        }
        else if(weight<=20){
            use = (Usegas*120)/100;
        }
        else {
            use = (Usegas*130)/100;
        }
        if(use<gas){
            gas = gas-use;
        }
        else {
            System.out.println("You cannot drive too far, please add gas");
        }    
    }   
}
