/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

/**
 *
 * @author piyawan
 */
public class Question {
    public String text;
    public String answer;
    public Question(){
        
    }
    public Question(String question){
        this.text=question;
    }
    public void setAnswer(String answer){
        this.answer=answer;
    }
    public void setText(String text){
       this.text=text;
    }
    public String getText(){
        return text;
    }
    public String getAnswer(){
        return answer;
    }
    public boolean checkAnswer(String response){
        boolean answer = false;
        if(response.equals(answer)){
            answer=true;}    
        return answer;
    }
    public void display(){
        System.out.println(text);
    }
    
}
