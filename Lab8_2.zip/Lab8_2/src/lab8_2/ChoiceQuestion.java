/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;
import java.util.ArrayList;
public class ChoiceQuestion extends Question{
    ArrayList<String> choices = new ArrayList<>();
    public ChoiceQuestion(String text){
        super(text);
    }
    
    public void addChoice(String choice,boolean correct){
       choices.add(choice);
       if(correct){
           super.setAnswer(choice);
       }  
    }
    @Override
    public void display(){
       super.display();
       for(int i = 0;i<choices.size()-1;i++){
           System.out.println((i+1)+":"+choices.get(i));
       }
    }
    @Override
    public boolean checkAnswer(String response){
        int i = Integer.parseInt(response);
        choices.get(i);
        boolean same = false;
        same = super.getAnswer().equals(choices.get(i));
        return same;
    }
    
}
