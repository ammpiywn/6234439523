/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;


public class WriteData {
    public static void main(String[] args) throws FileNotFoundException {
        Scanner data = new Scanner(System.in);
        PrintWriter list = new PrintWriter("list.txt");
        int character = 0;
        int word = 0;
        int line = 0;
        boolean loop = true;
        while(loop){
            String str = data.nextLine();
            if(!str.equals("quit")){
                list.println(str);
                line++;
                character+=str.length();
                String[] ch = str.split(" ");
                word+=ch.length;
            }
            else{
                loop=false;
            }
        }
        data.close();
        list.close();
        
        System.out.println("Total charaters :"+character);
        System.out.println("Total words :"+word);
        System.out.println("Total lines :"+line);
    } 
}
