/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_2;

/**
 *
 * @author piyawan
 */
public class DigitExtractor {
    private int number;
    private int digit;
    public DigitExtractor(int anInteger)
    {
    number = anInteger;
    }
    public int nextDigit()
    {
    digit = number%10;
    number= number/10;
    return digit;
    }
    
}
