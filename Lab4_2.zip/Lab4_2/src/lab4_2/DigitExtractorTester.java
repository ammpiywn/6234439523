/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_2;
import java.util.Scanner;

/**
 *
 * @author piyawan
 */
public class DigitExtractorTester {
    public static void main(String[] args)
    {
    Scanner num = new Scanner(System.in);
    System.out.print("Enter a positive number:");
    int numb = num.nextInt();
    DigitExtractor digit = new DigitExtractor(numb);
    System.out.println(digit.nextDigit());
    System.out.println(digit.nextDigit());
    System.out.println(digit.nextDigit());
    System.out.println(digit.nextDigit());
    System.out.println(digit.nextDigit());
    }
    
}
