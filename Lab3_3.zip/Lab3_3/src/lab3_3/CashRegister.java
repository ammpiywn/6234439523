/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3_3;

/**
 *
 * @author piyawan
 */
public class CashRegister {
    private double tax;
    private double balance;
    private double price;
    private double allTax;
    private double give;
    public CashRegister(double taxRate)
    {
        tax=taxRate;
    }
    public void enterPayment(double money)
    {
        balance+=money;
    }
    public void recordPurchase(double cost)
    {
        price+=cost;
    }
    public void recordTaxablePurchase(double cost)
    {
        price+=cost+(cost*tax/100.0);
        allTax+=(cost*tax/100.0);
    }
    public double getTotalTax()
    {
        return allTax; 
    }
    public double giveChange()
    {
        give=balance-price;
        give=(Math.round(give*10.0))/10.0;
        return give;
    }

   
}
