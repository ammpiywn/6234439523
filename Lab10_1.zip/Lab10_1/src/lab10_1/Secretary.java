/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;
public class Secretary extends Employee implements Evaluation{
    private int typingSpeed;
    private int score[];
    public Secretary(String name,int salary,int sc[],int typingSpeed){
        super(name);
        super.setSalary(salary);
        this.score=sc;
        this.typingSpeed=typingSpeed;
    }
    @Override
    public double evaluate(){
        int scores = 0;
        for(int i = 0;i<score.length;i++){
            scores += score[i];
        }
        return scores;
    }
    @Override
    public char grade(double scores){
        char grade = 'G';
        if(scores>=90){
            super.setSalary(18000);
            grade = 'p';
        }
        else{
            grade = 'F';
        }
        return grade;
    }
}
