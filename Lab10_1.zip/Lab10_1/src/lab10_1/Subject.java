/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;
public class Subject implements Evaluation{
    private final String subjName;
    private final int score[];
    public Subject(String subjName,int score[]){
        this.subjName=subjName;
        this.score=score;
    }
    @Override
    public double evaluate(){
        int Scores = 0;
        for(int i=0;i<score.length;i++){
            Scores += score[i];
        }
        double Average = Scores/score.length;
        return Average;
    }
    @Override
    public char grade(double Average){
        char grade = 'G';
        if(Average>=70){
           grade = 'p';        
        }
        else{
           grade = 'F'; 
        }
        return grade;
    }
    public String toString(){
        return subjName;
    }
}
