/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_3;
public class TransactionRecord {
    private int acctNo;
    private double amtTran;
    public TransactionRecord(int acctNo,double amtTran){
        this.acctNo=acctNo;
        this.amtTran=amtTran;
    }
    public void setAcctNo(int number){
        acctNo=number;
    }
    public void setAmtTran(int number){
        amtTran=number;
    }
    public int getAcctNo(){
        return acctNo;
    }
    public double getAmtTran(){
        return amtTran;
    }
}
