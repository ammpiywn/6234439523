/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;
import java.util.ArrayList;
public class BusTester {
    public static void main(String[] args){
        ArrayList<Bus> arr = new ArrayList<Bus>(2);
        arr.add(new Hybrid(45,1.2,600,150,1));
        arr.add(new CNGBus(50,1,200,2));
        for(Bus i : arr){
            if(i instanceof Hybrid){
                Hybrid j = (Hybrid) i;
                System.out.println("ID: "+i.getID());
                System.out.println("Emisson Tier: "+j.getEmissionTier());
                System.out.println("Accel: "+j.getAccel());
            }
            else if(i instanceof CNGBus){
                CNGBus k = (CNGBus) i;
                System.out.println("ID: "+i.getID());
                System.out.println("Emission Tier: "+k.getEmissionTier());
                System.out.println("Accel: "+k.getAccel());
            }
        }
    }
}
