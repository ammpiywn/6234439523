/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;
import java.util.ArrayList;
public class MusicBox implements SimpleQueue{
    ArrayList<String> q = new ArrayList<>();
    public MusicBox(){
        
    }
    public void enqueue(Object o){
        q.add((String)o);
        System.out.println(o+" is added in queue ");
    }
    public void dequeue(){
       System.out.println(" Now playing "+q.get(0));
       q.remove(0);
    }
}
