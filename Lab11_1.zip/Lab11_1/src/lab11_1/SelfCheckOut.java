/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;
import java.util.ArrayList;
public class SelfCheckOut implements SimpleQueue{
    private double total = 0;
    ArrayList<Product> queue = new ArrayList<>();
    public SelfCheckOut(){
    }
    public void enqueue(Object o){
        queue.add((Product)o);
        System.out.println(((Product)o).getName()+" is added in queue "); 
    }
    public void dequeue(){
        total = total +(queue.get(0)).getPrice();
        queue.remove(0);
    }
    public double getAmount(){
        return total;
    }
    
}
