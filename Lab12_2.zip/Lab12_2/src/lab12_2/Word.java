
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_2;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
public class Word {
    public static void main(String[] args) {  
        ArrayList<String> words = new ArrayList<>();
        String wordlists ;
        File file = new File("wordlist.txt");
        try{
            Scanner wordlist = new Scanner(file);
            while(wordlist.hasNextLine()){
                wordlists = wordlist.nextLine();
                words.add(wordlists);
            }
        }
        catch(FileNotFoundException e){
            System.out.println(e);
        }
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String in = input.nextLine();
        System.out.println("Words not contained: ");   
        int cnt = 0;
        String[] message = in.split(" ");
        for(String word : message){
            if(words.indexOf(word)<0){
                System.out.println(word);
                cnt++;
            }
        }
        if(cnt<=0){
            System.out.println("N/A");
        }
    }       
}

    
