/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

import java.util.ArrayList;

/**
 *
 * @author usci
 */
public class Purse {
    private String allPurse;
    private String allpurses;
    ArrayList<String> purse = new ArrayList<>();
    public void addCoin(String coinName)
    {
    purse.add(coinName);
    }
    @Override
    public String toString()
    {
    allPurse="purse"+purse;
    return allPurse;
    }
    public ArrayList<String>reverse()
    {
        ArrayList<String> reverse = new ArrayList<>();
        for(int i = purse.size()-1;i>=0;i--){
            reverse.add(purse.get(i));
        }
        return purse = reverse;
    }
    public void transfer(Purse other)
    {
        while (purse.size()>0)
        {
            other.purse.add(purse.get(0));
            purse.remove(0);
        }
    }
    public boolean sameContent(Purse other)
    {
        return this.purse.equals(other.purse);
    }
    public boolean sameCoins(Purse other)
    {
        boolean same = false;
        for(int i =0; i<=this.purse.size()-1; i++){
            for(int n=0;n<=other.purse.size()-1; n++){
                same = this.purse.get(i).equals(other.purse.get(n));
                if(same==true) break;
            }if(same==false) break;
        }return same;
    }
}
