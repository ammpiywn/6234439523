/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;

/**
 *
 * @author piyawan
 */
public class purseTester {
    public static void main(String[] args){
        Purse a = new Purse();
        Purse b = new Purse();
        a.addCoin("Quarter");
        a.addCoin("Dime");
        a.addCoin("Nickel");
        a.addCoin("Dime");
        b.addCoin("Nickel");
        b.addCoin("Dime");
        b.addCoin("Dime");
        b.addCoin("Quanter");
        System.out.println("a = "+a.toString()); //test addCoin and toString
        System.out.println("b = "+b.toString());
        
        System.out.println("a.sameContents(b) : "+a.sameContent(b)); //test sameContent
        System.out.println("a.sameCoins(b) : "+a.sameCoins(b)); //test sameCoin
        
        a.reverse();
        System.out.println("reverse a = "+a.toString());//test reverse
        
        a.transfer(b);//test transfer
        System.out.println("a after a.transfer(b) : "+a);
        System.out.println("b after b.transfer(b) : "+b);
        
        Purse c = new Purse();
        Purse d = new Purse();
        c.addCoin("Quarter");
        c.addCoin("Dime");
        c.addCoin("Nickel");
        c.addCoin("Quarter");
        d.addCoin("Quanter");
        d.addCoin("Dime");
        d.addCoin("Nickel");
        d.addCoin("Quanter");
        System.out.println("c = "+c.toString());
        System.out.println("d = "+d.toString());
        System.out.println("c.sameContent(d) : "+c.sameContent(d));
        System.out.println("c.sameCoins(d) : "+c.sameCoins(d));
        
        Purse e = new Purse();
        Purse f = new Purse();
        e.addCoin("Quarter");
        e.addCoin("Dime");
        e.addCoin("Nickel");
        f.addCoin("Nickel");
        f.addCoin("Quarter");
        System.out.println("e = "+e.toString());
        System.out.println("f = "+f.toString());
        System.out.println("e.sameContent(f) : "+e.sameContent(f));
        System.out.println("e.sameCoins(f) : "+e.sameCoins(f));
    }
}
