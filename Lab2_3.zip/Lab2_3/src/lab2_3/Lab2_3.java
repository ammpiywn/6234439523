/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;

/**
 *
 * @author piyawan
 */
import java.util.Calendar;
import java.util.GregorianCalendar;
public class Lab2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar today = new GregorianCalendar(2020,Calendar.JANUARY,12);
        GregorianCalendar birthday = new GregorianCalendar(1990,Calendar.MARCH,12);
        today.add(Calendar.DAY_OF_MONTH,100);
        birthday.add(Calendar.DAY_OF_MONTH,10000);
        
        int dayOfWeek = today.get(Calendar.DAY_OF_WEEK);
        int dayOfMonth = today.get(Calendar.DAY_OF_MONTH);
        int Month = today.get(Calendar.MONTH);
        int year = today.get(Calendar.YEAR);
        
        int bOfWeek = birthday.get(Calendar.DAY_OF_WEEK);
        int bOfMonth = birthday.get(Calendar.DAY_OF_MONTH);
        int bmonth = birthday.get(Calendar.MONTH);
        int byear = birthday.get(Calendar.YEAR);
        
        System.out.println(dayOfWeek+" "+dayOfMonth+" "+Month+" "+year);
        System.out.println(bOfWeek+" "+bOfMonth+" "+bmonth+" "+byear);
        
        
    }
    
}
