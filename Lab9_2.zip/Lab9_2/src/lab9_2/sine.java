/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;
public class sine extends Taylor{
    public sine(int k,double x){
        super(k,x);
    }
    @Override
    public double getApprox(){
        double si = 0;
        for(int n=0;n<=getlter();n++){
            si += (Math.pow(-1,n)*Math.pow(getValue(),(2*n)+1)/factorial((2*n)+1));
        }
        return si;
    }
    @Override
    public void printValue(){
        double s = Math.sin(getValue());
        System.out.println("Value from Math.sine() is "+s);
        System.out.println("Approximated value is "+getApprox());
    }
    
}
