/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;

/**
 *
 * @author Administrator
 */
public class cosine extends Taylor{
    public cosine(int k,double x){
        super(k,x);
    }
    @Override
    public double getApprox(){
        double co = 0;
        for(int n=0;n<=getlter();n++){
            co += (Math.pow(-1,n)*Math.pow(getValue(),(2*n))/factorial(2*n));
        }
        return co;
    }
    @Override
    public void printValue(){
        double c = Math.cos(getValue());
        System.out.println("Value from Math.cos() is "+c);
        System.out.println("Approximated value is "+getApprox());
    }
}
