/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_2;
public class expo extends Taylor{
    public expo(int k,double x){
        super(k,x);
    }
    @Override
    public double getApprox(){
        double ex = 0;
        for(int n=0;n<=getlter();n++){
            ex += (Math.pow(getValue(),n)/factorial(n));
        }
        return ex;
    }
    @Override
    public void printValue(){
        double e = Math.exp(getValue());
        System.out.println("Value from Math.exp() is "+e);
        System.out.println("Approximated value is "+getApprox());
    }
        
}
