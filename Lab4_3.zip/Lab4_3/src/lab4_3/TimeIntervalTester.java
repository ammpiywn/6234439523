/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;
import java.util.Scanner;

/**
 *
 * @author piyawan
 */
public class TimeIntervalTester {
    public static void main(String[] args)
    {
        System.out.print("Enter start time:");
        Scanner Start = new Scanner(System.in);
        int timeStart=Start.nextInt();
        System.out.print("Enter end time:");
        Scanner Stop = new Scanner(System.in);
        int timeStop = Stop.nextInt();
        TimeInterval time = new TimeInterval(timeStart,timeStop);
        System.out.print(time.getHour()+" "+"hours"+" ");
        System.out.println(time.getMinutes()+" "+"minutes");
        
        
        
        
        
        
        
        
    }
    
}
