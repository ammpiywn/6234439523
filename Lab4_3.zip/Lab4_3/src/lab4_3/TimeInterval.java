/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;


/**
 *
 * @author piyawan
 */
public class TimeInterval {
    private final int timeStart;
    private final int timeStop;
    private final int tStart;
    private final int tStop;
    private final int tStart1;
    private final int tStop1;
    private final int times;
public TimeInterval(int start,int stop)
    {
    timeStart=start;
    timeStop=stop;
    tStart=(timeStart/100)*60;
    tStop=(timeStop/100)*60;
    tStart1=timeStart%100;
    tStop1=timeStop%100;
    times=(tStop+tStop1)-(tStart+tStart1);
    }
public int getHour()
{
    int hours=times/60;
    return hours;
}
public int getMinutes()
{
   int minutes=times%60;
   return minutes;
}
}
